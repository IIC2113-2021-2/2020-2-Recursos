﻿namespace Nadaje
{
    class Program
    {
        public static void Main(string[] args)
        {
            var backend = new Backend();
            var frontend = new FrontEnd();
            frontend.ConnectToBackend(backend);
            frontend.Menu();
        }
    }
}
