# Ejecución

Se puede ejecutar el programa con:

``dotnet build``
``dotnet run``

# Patrón incorporado

Se utilizó el patrón Strategy para el manejo del frontend y backend.

