using System;

namespace Nadaje    {
    class FrontEnd{
        IClientInterface MyBackend {get; set;}
        bool On {get; set;} = true;
        public void Menu(){
            while(On){
                Run();
            }
        }
        private void Run(){
                Console.WriteLine(MyBackend.ListMovies());
                Console.Write("Seleccione una pelicula: ");
                var command = Console.ReadLine();
                if(command.Equals("exit")){
                    On = false;
                    return;
                }
                var number = Convert.ToInt32(command);
                ShowMovie(number);
        }
        public void ConnectToBackend(IClientInterface backend){
            MyBackend = backend;
        }
        private void ShowMovie(int number){
            Console.WriteLine("\n");
            Console.WriteLine(MyBackend.GetMovie(number));
            Console.WriteLine("1. Calificar");
            Console.WriteLine("2. Review");
            Console.WriteLine("3. Volver");
            Console.Write("Seleccione una acción: ");
            var inputNumber = Convert.ToInt32(Console.ReadLine());

            var qualify = 1;
            var review = 2;
            var goBack = 3;

            if (inputNumber == qualify){
                Console.Write("Ingrese un número del 1 al 5: ");
                var rate = float.Parse(Console.ReadLine());
                MyBackend.UpdateUserRating(rate, number);
                return;
            }
            if (inputNumber == review){
                Console.WriteLine("No implementado");
                return;
            }
            if (inputNumber == goBack){
                return;
            }

            Console.WriteLine("Se equivocó");
            return;
        }
    }
}