using System.Collections.Generic;
using System.Linq;

namespace Nadaje
{
    public interface IMovie{
        public string Title {get; set;}
        public void Update(IReview review);
        public string ShowInfo();
        public void SetDefinitive(Dictionary<string, IScale> metadata);
        public void UpdateUserRating(float rate);
        public float DefinitiveClassification {get; set;}
    }
    public class Movie: IMovie
    {
        public string Title {get; set;}
        private string _description;
        public Dictionary<string, string> RealeaseDate {get; set;} = new Dictionary<string, string>();
        private Dictionary<string, float> _rating = new Dictionary<string, float>();
        public Dictionary<string, float> Rating {get; set;} = new Dictionary<string, float>();
        public float DefinitiveClassification {get; set;}
        public float? UserRating {get; set;} = null;
        public Movie(IReview review){
            Title = review.GetTitle()[0].ToString().ToUpper() + review.GetTitle().Substring(1).ToLower();
            _description = review.GetDescription();
            Rating.Add(review.ReviewType, review.Qualification());
            RealeaseDate.Add(review.ReviewType, review.GetRealeaseDate());
        }
        public void Update(IReview review){
            UpdateDescrition(review.GetDescription());
            Rating[review.ReviewType] = review.Qualification();
            RealeaseDate.Add(review.ReviewType, review.GetRealeaseDate());
            return;
        }
        private void UpdateDescrition(string description){
            var descriptionWasEmpty = _description.Equals("");
            var isNotEmpty = !description.Equals("");
            var isShorterDescription = description.Length < _description.Length? true : false;
            if(descriptionWasEmpty){
                _description = description;
                return;
            }
            if(isNotEmpty && isShorterDescription){
                 _description = description;
                 return;
            }
        }
        public string ShowInfo(){
            string imdb = Rating.ContainsKey(ReviewTypes.IMDB) ? Rating[ReviewTypes.IMDB].ToString("F") : "n/a";
            string metacritic = Rating.ContainsKey(ReviewTypes.METACRITIC) ? Rating[ReviewTypes.METACRITIC].ToString("F") : "n/a";
            string rotten = Rating.ContainsKey(ReviewTypes.ROTTEN) ? Rating[ReviewTypes.ROTTEN].ToString("F") : "n/a";
            string user = Rating.ContainsKey(ReviewTypes.USER) ? $"{Rating[ReviewTypes.USER]}" : "n/a";
            string definitiveClassification = $"{DefinitiveClassification.ToString("F")}";
            return 
            Title + "\n" +
            "Calificación definitiva: " + definitiveClassification +"\n" +
            "IMDB: " + imdb + "\n" +
            "Rotten Tomatoes: " + rotten + "\n" +
            "Metascore: " + metacritic + "\n" +
            "Mi calificación: " + user + "\n" +
            "Descripción: " + _description + "\n" +
            "Año: " + GetRealeaseDate();
        }

        public void UpdateUserRating(float rate){
            if(!Rating.ContainsKey(ReviewTypes.USER)){
                Rating.Add(ReviewTypes.USER, rate);
                return;
            }
            Rating[ReviewTypes.USER] = rate;
            return;
        }
        private string GetRealeaseDate(){
            if (RealeaseDate.ContainsKey(ReviewTypes.IMDB)){
                return RealeaseDate[ReviewTypes.IMDB];
            }
            if (RealeaseDate.ContainsKey(ReviewTypes.METACRITIC)){
                return RealeaseDate[ReviewTypes.METACRITIC];
            }
            if (RealeaseDate.ContainsKey(ReviewTypes.ROTTEN)){
                return RealeaseDate[ReviewTypes.ROTTEN];
            }
            return "n/a";
        }

        public void SetDefinitive(Dictionary<string, IScale> metadata){
            var scores = new List<float>();
            foreach(var score in Rating)
            {
                var maxValue = metadata[score.Key].Max;
                var realValue = score.Value;
                var minValue = metadata[score.Key].Min;
                var normalizeRating = Calculator.Normalize(realValue, maxValue, minValue);
                scores.Add(normalizeRating);
            }
            DefinitiveClassification = scores.Average();
        }
    }
    public class Calculator{
        public static float Normalize(float realValue, float maxValue, float minValue){
            float numerator = realValue - minValue;
            float denominator = maxValue - minValue;
            return numerator/denominator;
        }
    }
}

