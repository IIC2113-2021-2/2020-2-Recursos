namespace Nadaje

{
    public interface IScale {
        public float Min {get; set;}
        public float Max {get; set;}
    }
    public class ImdbScale:IScale {
        public float Min {get; set;} = 1;
        public float Max {get; set;} = 10;
    }

    public class MetacriticScale:IScale {
        public float Min {get; set;} = 1;
        public float Max {get; set;} = 100;
    }

    public class RottenScale:IScale {
        public float Min {get; set;} = 1;
        public float Max {get; set;} = 100;
    }

    public class UserScale:IScale {
        public float Min {get; set;} = 1;
        public float Max {get; set;} = 5;
    }
}
