namespace Nadaje
{
    public class ReviewTypes {
        public static readonly string IMDB = "IMDB";
        public static readonly string METACRITIC = "METACRITIC";
        public static readonly string ROTTEN = "ROTTEN";
        public static readonly string USER = "USER";
    }
}
