using System.Collections.Generic;
using System.Linq;

namespace Nadaje
{
    public interface IMovieRepository{
        public List<IMovie> Movies {get; set;}
        public void addMovie(IReview review);
        public void ToList();
        public string PrintMovies();
        public Dictionary<string, IScale> MoviesScale {get; set;}
    }
    public class MovieRepository:IMovieRepository {
        public List<IMovie> Movies {get; set;} = new List<IMovie>();
        private Dictionary<string, IMovie> _moviesDatabase = new Dictionary<string, IMovie>();

        public Dictionary<string, IScale> MoviesScale {get; set;} = new Dictionary<string, IScale>();

        public MovieRepository(){
            AddMetaData();
        }

        private string parseTitle(string title){
            return title[0].ToString().ToUpper() + title.Substring(1).ToLower();
        }

        public void addMovie(IReview review){
            var movieTitle = parseTitle(review.GetTitle());
            var movieExistInRepository = _moviesDatabase.ContainsKey(movieTitle);
            IMovie movie;
            if(movieExistInRepository){
                _moviesDatabase[movieTitle].Update(review);
                return;
            }
            movie = new Movie(review);
            _moviesDatabase.Add(movieTitle, movie);
            return;
        }

        private void AddMetaData(){
            MoviesScale.Add(ReviewTypes.IMDB, new ImdbScale());
            MoviesScale.Add(ReviewTypes.METACRITIC, new MetacriticScale());
            MoviesScale.Add(ReviewTypes.ROTTEN, new RottenScale());
            MoviesScale.Add(ReviewTypes.USER, new UserScale());
        }

        public void ToList(){
            foreach(var movie in _moviesDatabase){
                movie.Value.SetDefinitive(MoviesScale);
                Movies.Add(movie.Value);
            }
        }

        public string PrintMovies()
        {
            int movieIndex = 1;
            var moviesList = "";
            Movies = Movies.OrderByDescending(movie=>movie.DefinitiveClassification).ToList();
            foreach (Movie movie in Movies){
                moviesList += $"\n{movieIndex.ToString()}. {movie.Title} ({movie.DefinitiveClassification.ToString("F")})";
                movieIndex ++;
            }
            return moviesList;
        }
    }
}

