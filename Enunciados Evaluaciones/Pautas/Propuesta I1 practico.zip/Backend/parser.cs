using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Nadaje
{
    public interface IReview {

        public string GetTitle();
        public float Qualification(); 
        public string GetDescription();
        public string GetRealeaseDate();
        string ReviewType { get; }
    }

    public class Rotten : IReview   {
        public string title { get; set; } 
        public string criticsconsensus { get; set; } 
        public int tomatometer { get; set; }

        public string GetTitle(){
            return title;
        }
        public float Qualification(){
            return tomatometer;
        }
        public string GetDescription(){
            return "";
        }
        public string GetRealeaseDate(){
            return "n/a" ;
        }
        public string ReviewType { get; } = ReviewTypes.ROTTEN;
    }

    public class IMDB : IReview   {
        static float minRating {get; set;}
        public string name { get; set; } 
        public double rating { get; set; } 
        public int year { get; set; } 
        public string genre { get; set; } 
        public string summary { get; set; } 
        public string director { get; set; } 
        public string writers { get; set; } 
        public string stars { get; set; }
        public string ReviewType {get;} = ReviewTypes.IMDB;

        public string GetDescription()
        {
            return summary;
        }

        public string GetRealeaseDate()
        {
            return year.ToString();
        }

        public string GetTitle()
        {
            return name;
        }

        public float Qualification()
        {
            return (float) rating;
        }
    }

    public class Metacritic: IReview    {
        public string name { get; set; } 
        public int metascore { get; set; } 
        public Details details { get; set; } 
        public string GetTitle(){
            return name;
        }
        public float Qualification(){
            return metascore;
        }
        public string GetDescription(){
            return details.summary;
        }
        public string GetRealeaseDate(){
            return details.year ;
        }
        public string ReviewType { get; } = ReviewTypes.METACRITIC;
    }

    public class IMDBlist    {
        public List<IMDB> movies { get; set; } 
    }

    public class MetacriticList   {
        public List<Metacritic> critics { get; set; } 
    }

    public class RottenList   {
        public List<Rotten> critics { get; set; } 
    }

    public class Details    {
        public string year { get; set; } 
        public string starring { get; set; } 
        public string summary { get; set; } 
    }

    public class Deserializer {

        public static IMDBlist deserializeImdb(){
            string json = System.IO.File.ReadAllText("./Data/imdb.json");
            return JsonConvert.DeserializeObject<IMDBlist>(json); 
        }

        public static MetacriticList deserializeMetacritic(){
            string json = System.IO.File.ReadAllText("./Data/metacritic.json");
            return JsonConvert.DeserializeObject<MetacriticList>(json);
        }
        public static RottenList deserializeRotten(){
            string json = System.IO.File.ReadAllText("./Data/rotten.json");
            string fixedJson = Regex.Replace(json, "\"(\\w*) (\\w*)\": ", "\"$1$2\": ");
            return JsonConvert.DeserializeObject<RottenList>(json);
        }
    }
}