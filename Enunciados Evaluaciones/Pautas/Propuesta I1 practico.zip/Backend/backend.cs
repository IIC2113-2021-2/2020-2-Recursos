namespace Nadaje

{
    public interface IClientInterface{
        public void Setup();
        public string ListMovies();
        public string GetMovie(int number);
        public void UpdateUserRating(float rate, int number);
    }

    public class Backend: IClientInterface{

        IMovieRepository MyMovieRepository {get; set; }
        public Backend(){
            MyMovieRepository = new MovieRepository();
            Setup();
        }

        public void Setup(){

            var imdbDeserialized = Deserializer.deserializeImdb();
            var metacriticDeserialized = Deserializer.deserializeMetacritic();
            var rottenDeserialized = Deserializer.deserializeRotten();

            foreach (IMDB imdb in imdbDeserialized.movies){
                MyMovieRepository.addMovie(imdb);
            }

            foreach (Metacritic metacritic in metacriticDeserialized.critics){
                MyMovieRepository.addMovie(metacritic);
            }

            foreach (Rotten rotten in rottenDeserialized.critics){
                MyMovieRepository.addMovie(rotten);
            }

            MyMovieRepository.ToList();
        }

        public string ListMovies(){
            return MyMovieRepository.PrintMovies();
        }

        public string GetMovie(int number){
            var index = number - 1;
            return MyMovieRepository.Movies[index].ShowInfo();
        }

        public void UpdateUserRating(float rate, int number){
            var index = number - 1;
            var movie = MyMovieRepository.Movies[index];
            movie.UpdateUserRating(rate);
            movie.SetDefinitive(MyMovieRepository.MoviesScale);
        }
    }
}

